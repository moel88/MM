kill @e[tag=cliffcity_training]
